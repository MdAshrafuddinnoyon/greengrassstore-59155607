# 🌿 GREEN GRASS STORE - COMPLETE DEPLOYMENT GUIDE
# সম্পূর্ণ ডিপ্লয়মেন্ট গাইড

---

## 📦 Package Contents / প্যাকেজ কন্টেন্ট

এই folder এ যা আছে:

```
HOSTINGER_FINAL_PACKAGE/
├── index.html           # Main HTML file
├── .htaccess            # Apache configuration  
├── robots.txt           # SEO configuration
├── assets/              # CSS, JS, Images
├── api/                 # PHP backend files
├── database/            # Database setup files
│   ├── COMPLETE_DATABASE_SETUP.sql
│   └── DATABASE_SETUP_GUIDE_BANGLA.md
└── docs/                # Documentation files
    ├── DEPLOYMENT_STEPS.md (this file)
    └── TROUBLESHOOTING.md
```

---

## 🚀 DEPLOYMENT STEPS / ডিপ্লয়মেন্ট ধাপসমূহ

### ধাপ ১: Hostinger File Manager এ Upload করুন

1. **Hostinger cPanel এ login করুন**
   - আপনার Hostinger account → Hosting → Manage

2. **File Manager খুলুন**
   - Advanced section → File Manager click করুন
   - `public_html` folder এ যান

3. **পুরানো files মুছে ফেলুন (যদি থাকে)**
   - `public_html` এর সব files select করুন (Ctrl+A)
   - Delete button click করুন
   - **সতর্কতা:** Backup নিয়ে নিন আগে!

4. **নতুন files upload করুন**
   - `HOSTINGER_FINAL_PACKAGE` folder এর **ভিতরের সব কিছু** select করুন
   - File Manager এ "Upload" button click করুন
   - অথবা ZIP করে upload করে Extract করুন

   **Important:** Folder structure এমন হতে হবে:
   ```
   public_html/
   ├── index.html
   ├── .htaccess
   ├── assets/
   ├── api/
   └── database/
   ```

---

### ধাপ ২: Database Setup করুন

1. **cPanel থেকে phpMyAdmin খুলুন**

2. **`database/COMPLETE_DATABASE_SETUP.sql` file টি import করুন**
   - phpMyAdmin → Import tab
   - Choose File → SQL file select করুন
   - Go button click করুন

3. **বিস্তারিত instructions:**
   - `database/DATABASE_SETUP_GUIDE_BANGLA.md` file দেখুন

---

### ধাপ ৩: Database Connection Configure করুন

1. **File Manager এ `api/config.php` file খুলুন**

2. **Edit করুন:**
   ```php
   <?php
   define('DB_HOST', 'localhost');
   define('DB_NAME', 'greengrassstore'); // আপনার database name
   define('DB_USER', 'your_username');   // cPanel থেকে পাবেন
   define('DB_PASS', 'your_password');   // cPanel থেকে পাবেন
   ?>
   ```

3. **Database credentials পেতে:**
   - cPanel → MySQL Databases
   - আপনার database username এবং password দেখুন

---

### ধাপ ৪: File Permissions Set করুন

1. **API folder এর permission check করুন:**
   - `api` folder right-click → Permissions
   - Set করুন: `755`

2. **Upload folder (যদি থাকে) permission:**
   - `api/uploads` folder → Permissions → `755`

---

### ধাপ ৫: Test Your Website

1. **Browser এ আপনার domain খুলুন:**
   - `https://yourdomain.com`

2. **Check করুন:**
   - ✅ Homepage load হচ্ছে
   - ✅ Products দেখাচ্ছে
   - ✅ Navigation কাজ করছে
   - ✅ Images load হচ্ছে

3. **Admin Panel access করুন:**
   - URL: `https://yourdomain.com/admin`
   - Email: `admin@greengrassstore.com`
   - Password: `admin123`
   - **First login এর পর password change করুন!**

---

## 🔧 POST-DEPLOYMENT CONFIGURATION

### ১. Admin Settings Update করুন

Admin Panel → Settings:

- **Store Information**
  - Store name
  - Email address
  - Phone number
  - Physical address

- **Payment Methods**
  - Enable/disable payment gateways
  - Configure payment credentials

- **Shipping Settings**
  - Set shipping rates
  - Free shipping threshold

- **Tax Settings**
  - VAT/Tax percentage

### ২. WhatsApp Integration

Admin Panel → Settings → WhatsApp:
- আপনার WhatsApp number দিন
- Welcome message customize করুন

### ৩. Email Configuration (Optional)

যদি email notifications চান:
- Admin Panel → Settings → SMTP
- আপনার email SMTP settings দিন

### ৪. Add Products

Admin Panel → Products:
- "Add New Product" click করুন
- Product details fill করুন
- Images upload করুন
- Save করুন

### ৫. Create Blog Posts

Admin Panel → Blog:
- "Create New Post" click করুন
- Content লিখুন
- Publish করুন

---

## ✅ CHECKLIST / চেকলিস্ট

Deploy করার পর এগুলো verify করুন:

- [ ] Homepage properly loading
- [ ] Products page showing items
- [ ] Shop page working
- [ ] Cart functionality working
- [ ] Checkout process working
- [ ] Blog page accessible
- [ ] About page loading
- [ ] Contact form submitting
- [ ] Admin panel accessible
- [ ] Admin login working
- [ ] Images displaying correctly
- [ ] WhatsApp button working
- [ ] Search functionality working
- [ ] Mobile responsive
- [ ] Arabic language switching

---

## 🌐 SSL Certificate (HTTPS)

Hostinger automatically provides free SSL:

1. cPanel → SSL/TLS Status
2. Check if SSL is active
3. যদি না থাকে: "Run AutoSSL" click করুন
4. 10-15 minutes wait করুন
5. Website `https://` দিয়ে access করুন

---

## 📱 TESTING ON MOBILE

1. আপনার mobile browser এ domain open করুন
2. Check করুন:
   - Responsive design
   - Touch interactions
   - WhatsApp button
   - Menu navigation

---

## 🔐 SECURITY RECOMMENDATIONS

1. **Admin Password Change করুন:**
   - Default password: `admin123` থেকে change করুন

2. **Database User Permission:**
   - শুধু necessary permissions দিন

3. **File Permissions:**
   - Sensitive files: `644`
   - Folders: `755`
   - কখনো `777` permission দেবেন না

4. **Regular Backups:**
   - Weekly database backup
   - Monthly full site backup

5. **.htaccess Security:**
   - Directory listing disable করা আছে
   - Sensitive files protected

---

## 📊 ANALYTICS SETUP (Optional)

### Google Analytics যোগ করতে:

1. Admin Panel → Settings → Tracking
2. Google Analytics tracking ID paste করুন
3. Save করুন

### Facebook Pixel যোগ করতে:

1. Admin Panel → Settings → Tracking  
2. Facebook Pixel ID paste করুন
3. Save করুন

---

## 🎨 CUSTOMIZATION

### Logo পরিবর্তন করতে:

1. Admin Panel → Branding
2. Logo upload করুন
3. Save করুন

### Colors পরিবর্তন করতে:

1. Admin Panel → Branding
2. Primary color select করুন
3. Secondary color select করুন
4. Save করুন

### Homepage Sections:

1. Admin Panel → Homepage
2. Enable/disable sections
3. Reorder sections
4. Save করুন

---

## 🐛 COMMON ISSUES / সাধারণ সমস্যা

### সমস্যা ১: "500 Internal Server Error"

**সমাধান:**
- `.htaccess` file check করুন
- File permissions verify করুন
- Error logs check করুন (cPanel → Error Logs)

### সমস্যা ২: Database Connection Error

**সমাধান:**
- `api/config.php` এ credentials check করুন
- Database exists কিনা verify করুন
- Database user এর permissions check করুন

### সমস্যা ৩: Images Not Loading

**সমাধান:**
- Image paths correct কিনা check করুন
- File permissions: images folder → `755`
- Browser cache clear করুন

### সমস্যা ৪: Admin Login Not Working

**সমাধান:**
- Database এ `users` table check করুন
- Admin user exists কিনা verify করুন
- Browser cookies enable করা আছে কিনা check করুন

### সমস্যা ৫: Pages Showing 404

**সমাধান:**
- `.htaccess` file properly uploaded কিনা check করুন
- Apache mod_rewrite enabled কিনা verify করুন
- File Manager এ `.htaccess` visible কিনা দেখুন

---

## 📞 SUPPORT

কোন সমস্যা হলে:

1. **Error Logs check করুন:**
   - cPanel → Metrics → Errors

2. **Browser Console check করুন:**
   - F12 → Console tab

3. **Database Logs:**
   - phpMyAdmin → SQL tab

4. **Hostinger Support:**
   - Live chat available 24/7

---

## 🎉 CONGRATULATIONS!

আপনার Green Grass Store website এখন live! 

### Next Steps:

1. ✅ Products যোগ করুন
2. ✅ Blog posts লিখুন  
3. ✅ Social media links update করুন
4. ✅ SEO optimize করুন
5. ✅ Google Search Console এ submit করুন

---

## 📚 ADDITIONAL RESOURCES

- `database/DATABASE_SETUP_GUIDE_BANGLA.md` - Database setup details
- `docs/TROUBLESHOOTING.md` - Common problems and solutions
- Hostinger Knowledge Base: https://support.hostinger.com

---

**Made with ❤️ for Green Grass Store**

**Version:** 3.1  
**Last Updated:** December 2025

---

## 🔄 UPDATE INSTRUCTIONS

যখন নতুন version deploy করতে চান:

1. **Backup নিন:**
   - Database export করুন
   - `public_html` folder download করুন

2. **New files upload করুন:**
   - Old files replace করুন
   - Database migrations run করুন (যদি থাকে)

3. **Cache clear করুন:**
   - Browser cache
   - Server cache (যদি enable করা থাকে)

4. **Test করুন:**
   - All major features verify করুন

---

**Happy Selling! 🌿**
