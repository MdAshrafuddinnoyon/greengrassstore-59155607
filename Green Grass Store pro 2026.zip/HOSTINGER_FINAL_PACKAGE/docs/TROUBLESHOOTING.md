# 🔧 TROUBLESHOOTING GUIDE
# সমস্যা সমাধান গাইড

---

## 🚨 CRITICAL ERRORS

### Error: "Cannot connect to database"

**লক্ষণ:**
- Website শুধু blank page দেখাচ্ছে
- Console এ database error

**সমাধান:**

1. **Database credentials verify করুন:**
   ```php
   // api/config.php check করুন
   define('DB_HOST', 'localhost'); // সঠিক?
   define('DB_NAME', 'greengrassstore'); // সঠিক?
   define('DB_USER', 'your_username'); // সঠিক?
   define('DB_PASS', 'your_password'); // সঠিক?
   ```

2. **Database exists কিনা check করুন:**
   - phpMyAdmin open করুন
   - Left sidebar এ database name দেখুন

3. **Database user permissions:**
   - cPanel → MySQL Databases
   - "Current Users" section check করুন
   - User কে database এ access দিন

4. **Localhost vs IP:**
   - `localhost` কাজ না করলে `127.0.0.1` try করুন

---

### Error: "500 Internal Server Error"

**লক্ষণ:**
- White page with "500 error"
- Website load হচ্ছে না

**সমাধান:**

1. **Error logs দেখুন:**
   - cPanel → Metrics → Errors
   - Last 10 errors check করুন

2. **.htaccess file check:**
   - File Manager এ `.htaccess` আছে কিনা দেখুন
   - Syntax error আছে কিনা verify করুন
   - Temporarily rename করে test করুন (`.htaccess.bak`)

3. **PHP version:**
   - cPanel → PHP Version
   - PHP 7.4 বা higher recommended

4. **File permissions:**
   - `api` folder → 755
   - PHP files → 644
   - Never use 777!

---

### Error: "404 Not Found" on all pages

**লক্ষণ:**
- Homepage ছাড়া সব page 404 দেখাচ্ছে
- `/shop`, `/about` etc. কাজ করছে না

**সমাধান:**

1. **.htaccess file missing:**
   - File Manager এ check করুন
   - Hidden files visible করুন (Settings)
   - `.htaccess` upload করুন

2. **mod_rewrite disabled:**
   - Hostinger এ default enabled থাকে
   - যদি না থাকে: Support contact করুন

3. **.htaccess content verify:**
   ```apache
   RewriteEngine On
   RewriteBase /
   RewriteCond %{REQUEST_FILENAME} !-f
   RewriteCond %{REQUEST_FILENAME} !-d
   RewriteRule . /index.html [L]
   ```

---

## 🖼️ IMAGE ISSUES

### Images not loading

**সমাধান:**

1. **Image paths check:**
   - Console (F12) তে 404 errors দেখুন
   - Path `/assets/` দিয়ে শুরু হচ্ছে কিনা

2. **File permissions:**
   - Images folder → 755
   - Image files → 644

3. **File names:**
   - Spaces remove করুন
   - Special characters avoid করুন
   - Lowercase use করুন

4. **Browser cache:**
   - Hard refresh: Ctrl+Shift+R
   - Clear browser cache

---

## 🔐 ADMIN PANEL ISSUES

### Cannot login to admin

**সমাধান:**

1. **Default credentials:**
   - Email: `admin@greengrassstore.com`
   - Password: `admin123`

2. **Database check:**
   ```sql
   SELECT * FROM users WHERE role = 'admin';
   ```
   - phpMyAdmin এ run করুন

3. **Reset admin password:**
   ```sql
   UPDATE users 
   SET password_hash = '$2a$10$rL5h0zKJ3yYxKxYH5rYxF.vKxH5kH5rYxF5rYxF5rYxF5rYxF5rY'
   WHERE email = 'admin@greengrassstore.com';
   ```
   - এটা password reset করবে `admin123` তে

4. **Cookies enabled:**
   - Browser settings check করুন
   - Incognito mode try করুন

---

### Admin panel blank/white screen

**সমাধান:**

1. **JavaScript errors:**
   - F12 → Console check করুন
   - Errors fix করুন

2. **Database connection:**
   - API calls failing কিনা দেখুন
   - Network tab check করুন

3. **Cache clear:**
   - Browser cache clear করুন
   - Server cache clear করুন

---

## 🛒 CHECKOUT ISSUES

### Order not creating

**লক্ষণ:**
- Checkout form submit হচ্ছে না
- Console এ "Unauthorized" error

**সমাধান:**

1. **Database policy check:**
   ```sql
   -- Run this in phpMyAdmin
   SHOW GRANTS FOR CURRENT_USER;
   ```

2. **Orders table verify:**
   ```sql
   SELECT * FROM orders LIMIT 1;
   ```

3. **Error logs:**
   - Browser Console (F12)
   - Network tab → Failed requests দেখুন

---

### Payment gateway not working

**সমাধান:**

1. **API credentials:**
   - Admin Panel → Payment Settings
   - Test mode enabled কিনা check করুন

2. **SSL certificate:**
   - HTTPS active কিনা verify করুন
   - Payment gateways HTTPS require করে

3. **Webhook URLs:**
   - Payment provider dashboard check করুন
   - Correct callback URL দিয়েছেন কিনা

---

## 📧 EMAIL ISSUES

### Emails not sending

**সমাধান:**

1. **SMTP configuration:**
   - Admin Panel → Settings → SMTP
   - Host, Port, Username, Password verify করুন

2. **PHP mail function:**
   - Hostinger এ default enabled
   - cPanel → Email Accounts check করুন

3. **Test email:**
   ```php
   // test.php file create করুন
   <?php
   $to = "your@email.com";
   $subject = "Test";
   $message = "Test email";
   mail($to, $subject, $message);
   echo "Email sent!";
   ?>
   ```

4. **Spam folder:**
   - Recipient এর spam check করুন

---

## 🌐 SSL/HTTPS ISSUES

### SSL not working

**সমাধান:**

1. **AutoSSL run:**
   - cPanel → SSL/TLS Status
   - "Run AutoSSL" click করুন

2. **Force HTTPS:**
   - `.htaccess` তে add করুন:
   ```apache
   RewriteEngine On
   RewriteCond %{HTTPS} off
   RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
   ```

3. **Mixed content:**
   - Console warning check করুন
   - সব resources HTTPS থেকে load করুন

---

## 📱 MOBILE ISSUES

### Not responsive on mobile

**সমাধান:**

1. **Viewport meta tag:**
   - `index.html` তে check করুন:
   ```html
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   ```

2. **CSS media queries:**
   - Browser DevTools → Device mode test করুন

3. **Touch events:**
   - Buttons clickable কিনা verify করুন

---

## 🔍 SEO ISSUES

### Not appearing in Google

**সমাধান:**

1. **robots.txt:**
   - `yourdomain.com/robots.txt` check করুন
   - Disallow না থাকলে ভালো

2. **Google Search Console:**
   - Submit your sitemap
   - URL inspection tool use করুন

3. **Meta tags:**
   - Title, description proper কিনা
   - Each page unique content

---

## ⚡ PERFORMANCE ISSUES

### Website loading slow

**সমাধান:**

1. **Image optimization:**
   - Large images compress করুন
   - WebP format use করুন
   - Max 200KB per image

2. **GZIP compression:**
   - `.htaccess` এ enabled আছে
   - cPanel → Optimize Website check করুন

3. **Browser caching:**
   - `.htaccess` caching rules আছে

4. **CDN (Optional):**
   - Cloudflare free plan use করুন

---

## 🗄️ DATABASE ISSUES

### Database too large

**সমাধান:**

1. **Old orders clean:**
   ```sql
   DELETE FROM orders WHERE created_at < DATE_SUB(NOW(), INTERVAL 1 YEAR);
   ```

2. **Optimize tables:**
   ```sql
   OPTIMIZE TABLE products, orders, blog_posts;
   ```

3. **Export/Archive:**
   - Old data export করুন
   - Separate database তে move করুন

---

### Database queries slow

**সমাধান:**

1. **Indexes check:**
   ```sql
   SHOW INDEX FROM products;
   ```

2. **Add indexes:**
   ```sql
   CREATE INDEX idx_product_category ON products(category);
   CREATE INDEX idx_order_status ON orders(status);
   ```

3. **Query optimization:**
   - phpMyAdmin → SQL tab
   - Slow queries identify করুন

---

## 🔄 UPDATE ISSUES

### After update, site broken

**সমাধান:**

1. **Restore backup:**
   - Previous version restore করুন
   - Database backup restore করুন

2. **Clear cache:**
   - Browser cache
   - Server cache
   - CDN cache (যদি থাকে)

3. **Check migration:**
   - Database migrations run হয়েছে কিনা
   - New columns added কিনা

---

## 📋 DEBUGGING CHECKLIST

যেকোনো সমস্যার জন্য এই steps follow করুন:

- [ ] Browser console errors check (F12)
- [ ] Network tab এ failed requests দেখুন
- [ ] cPanel error logs check করুন
- [ ] Database connection verify করুন
- [ ] File permissions check করুন
- [ ] .htaccess file verify করুন
- [ ] PHP version compatible কিনা
- [ ] SSL certificate active কিনা
- [ ] Browser cache clear করুন
- [ ] Different browser/device test করুন

---

## 🛠️ ADVANCED DEBUGGING

### Enable PHP error display (Development only!)

```php
// Add to api/config.php temporarily
error_reporting(E_ALL);
ini_set('display_errors', 1);
```

**Important:** Production এ এটা disable রাখুন!

---

### Browser DevTools usage

1. **Console tab:**
   - JavaScript errors দেখুন
   - console.log() outputs

2. **Network tab:**
   - Failed API calls
   - Slow requests
   - 404/500 errors

3. **Application tab:**
   - LocalStorage data
   - Cookies
   - Cache

---

## 📞 GET HELP

যদি কোন সমস্যার সমাধান না পান:

1. **Hostinger Support:**
   - Live chat: 24/7 available
   - Submit ticket with:
     - Error message
     - Screenshot
     - Steps to reproduce

2. **Community Forums:**
   - Hostinger Community
   - Stack Overflow

3. **Documentation:**
   - Check `DEPLOYMENT_STEPS.md`
   - Check `DATABASE_SETUP_GUIDE_BANGLA.md`

---

## ✅ PREVENTION TIPS

Future এ সমস্যা এড়াতে:

1. **Regular backups:**
   - Weekly database backup
   - Monthly full backup

2. **Test before deploy:**
   - Local environment এ test করুন
   - Staging site use করুন

3. **Update carefully:**
   - Backup নিয়ে তারপর update
   - One change at a time

4. **Monitor:**
   - Uptime monitoring
   - Error logs regularly check

5. **Security:**
   - Keep admin password strong
   - Regular security audits

---

**সমস্যা সমাধান হলে deployment guide follow করুন:** `DEPLOYMENT_STEPS.md`

**Happy Debugging! 🐛🔧**
