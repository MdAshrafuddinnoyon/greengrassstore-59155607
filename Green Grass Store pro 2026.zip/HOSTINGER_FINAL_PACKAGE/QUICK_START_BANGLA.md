# 🚀 দ্রুত শুরু করুন - QUICK START GUIDE

এই guide শুধু Hostinger এ deploy করার জন্য। বিস্তারিত জানতে `docs/DEPLOYMENT_STEPS.md` দেখুন।

---

## ⚡ 5 মিনিটে Deploy করুন

### ধাপ ১: Files Upload করুন (2 minutes)

1. Hostinger cPanel → File Manager
2. `public_html` folder এ যান
3. পুরানো files মুছে ফেলুন (যদি থাকে)
4. এই folder এর **সব কিছু** select করে upload করুন

**গুরুত্বপূর্ণ:** Folder টা upload না করে, folder এর **ভিতরের files** upload করুন!

```
✅ সঠিক:
public_html/
  ├── index.html
  ├── assets/
  ├── api/
  └── ...

❌ ভুল:
public_html/
  └── HOSTINGER_FINAL_PACKAGE/
      ├── index.html
      └── ...
```

---

### ধাপ ২: Database Setup (2 minutes)

1. cPanel → phpMyAdmin
2. "New" click করে database তৈরি করুন: `greengrassstore`
3. Database select করুন
4. "Import" tab → Choose File
5. `database/COMPLETE_DATABASE_SETUP.sql` select করুন
6. "Go" button click করুন
7. Success message wait করুন

---

### ধাপ ৩: Database Connection (1 minute)

1. File Manager → `api/config.php` open করুন
2. Edit করুন:

```php
<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'greengrassstore');
define('DB_USER', 'u123456_username');  // আপনার username
define('DB_PASS', 'your_password');      // আপনার password
?>
```

3. Save করুন

**Database credentials পেতে:**
- cPanel → MySQL Databases
- "Current Databases" section দেখুন

---

### ধাপ ৪: Test করুন

1. Browser এ খুলুন: `https://yourdomain.com`
2. Homepage load হচ্ছে? ✅
3. Admin login করুন: `https://yourdomain.com/admin`
   - Email: `admin@greengrassstore.com`
   - Password: `admin123`

---

## ✅ Deployment Complete!

আপনার website এখন live! 🎉

---

## 🔧 পরবর্তী কাজ (Optional)

1. **Admin Password Change করুন**
   - Admin Panel → Profile → Change Password

2. **Store Information Update করুন**
   - Admin Panel → Settings → Store Info
   - Name, Email, Phone, Address দিন

3. **Products যোগ করুন**
   - Admin Panel → Products → Add New
   - Product details এবং images upload করুন

4. **Blog Posts লিখুন**
   - Admin Panel → Blog → Create New
   - SEO এর জন্য helpful

5. **WhatsApp Number Update করুন**
   - Admin Panel → Settings → WhatsApp
   - আপনার number দিন

---

## 🐛 সমস্যা হলে?

### Website দেখাচ্ছে না?
- Browser cache clear করুন (Ctrl+Shift+R)
- Files properly upload হয়েছে কিনা check করুন
- Error logs: cPanel → Errors

### Database Connection Error?
- `api/config.php` credentials সঠিক কিনা verify করুন
- Database name, username, password check করুন
- phpMyAdmin এ database আছে কিনা দেখুন

### Admin Login কাজ করছে না?
- Default credentials: `admin@greengrassstore.com` / `admin123`
- Browser cookies enabled কিনা check করুন
- Incognito mode try করুন

### Images দেখাচ্ছে না?
- File permissions check করুন: folders = 755
- Browser console (F12) এ errors দেখুন
- Hard refresh করুন

---

## 📚 আরো সাহায্য

- **Full Guide:** `docs/DEPLOYMENT_STEPS.md`
- **Problems:** `docs/TROUBLESHOOTING.md`
- **Database:** `database/DATABASE_SETUP_GUIDE_BANGLA.md`
- **Hostinger Support:** Live chat 24/7

---

## 🎯 Success Checklist

Deploy করার পর এগুলো verify করুন:

- [ ] Homepage loading
- [ ] Shop page working
- [ ] Products showing
- [ ] Images displaying
- [ ] Admin panel accessible
- [ ] Admin login working
- [ ] WhatsApp button visible
- [ ] Mobile responsive
- [ ] HTTPS working

সব ✅ হলে আপনি ready! 🚀

---

**Happy Selling! 🌿**

*Need help? Check docs/ folder for detailed guides.*
