# ============================================
# GREEN GRASS STORE - DATABASE CONFIGURATION
# ============================================
# কীভাবে database setup করবেন
# ============================================

## ধাপ ১: Hostinger cPanel এ Login করুন

1. আপনার Hostinger account এ login করুন
2. "Hosting" section থেকে "Manage" click করুন
3. "Advanced" tab থেকে "phpMyAdmin" খুলুন

## ধাপ ২: Database তৈরি করুন

1. phpMyAdmin এ "Databases" tab এ যান
2. নতুন database এর নাম লিখুন: `greengrassstore`
3. Collation select করুন: `utf8mb4_unicode_ci`
4. "Create" button click করুন

## ধাপ ৩: SQL File Import করুন

1. Left sidebar থেকে আপনার নতুন database (`greengrassstore`) select করুন
2. Top menu থেকে "Import" tab click করুন
3. "Choose File" button click করে `COMPLETE_DATABASE_SETUP.sql` file select করুন
4. নিচে scroll করে "Go" button click করুন
5. Success message দেখার জন্য অপেক্ষা করুন

## ধাপ ৪: Database Connection Configure করুন

আপনার `api/config.php` file এ এই তথ্য দিন:

```php
<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'greengrassstore');
define('DB_USER', 'your_database_username');
define('DB_PASS', 'your_database_password');
?>
```

**Note:** Database username এবং password Hostinger cPanel এর MySQL Databases section থেকে পাবেন।

## ধাপ ৫: Admin Access

Database setup সম্পূর্ণ হলে এই credentials দিয়ে admin panel এ login করুন:

- Email: `admin@greengrassstore.com`
- Password: `admin123`

**গুরুত্বপূর্ণ:** First login এর পরে অবশ্যই admin password পরিবর্তন করুন!

## ধাপ ৬: Database Tables Verify করুন

phpMyAdmin এ check করুন এই tables তৈরি হয়েছে কিনা:

- ✅ products
- ✅ categories  
- ✅ blog_posts
- ✅ orders
- ✅ coupons
- ✅ site_settings
- ✅ subscribers
- ✅ users
- ✅ hero_sliders
- ✅ custom_requests

## Troubleshooting

### সমস্যা: Import এ error আসছে

**সমাধান:**
1. File size check করুন (max 50MB হওয়া উচিত)
2. যদি বড় হয় তাহলে sections এ ভাগ করে import করুন
3. SQL file UTF-8 encoding এ save করা আছে কিনা check করুন

### সমস্যা: Connection error

**সমাধান:**
1. Database name, username, password সঠিক আছে কিনা verify করুন
2. cPanel থেকে database user এর permissions check করুন
3. `localhost` এর জায়গায় `127.0.0.1` try করুন

## Additional Settings

### Sample Data যোগ করা (Optional)

যদি test products যোগ করতে চান:

```sql
INSERT INTO products (name, slug, description, price, category, is_active) VALUES
('Peace Lily', 'peace-lily', 'Beautiful indoor plant', 45.00, 'Indoor Plants', TRUE),
('Snake Plant', 'snake-plant', 'Low maintenance plant', 35.00, 'Indoor Plants', TRUE),
('Ceramic Pot', 'ceramic-pot', 'Modern ceramic planter', 25.00, 'Pots & Planters', TRUE);
```

### Backup নেওয়া

Regular backup নিতে:
1. phpMyAdmin এ আপনার database select করুন
2. "Export" tab এ যান
3. "Quick" method select করে "Go" click করুন
4. SQL file download হবে

## Support

কোন সমস্যা হলে database logs check করুন:
- cPanel → Error Logs
- phpMyAdmin → SQL tab এ queries test করুন

Database setup সম্পূর্ণ! 🎉
