-- ============================================
-- GREEN GRASS STORE - COMPLETE DATABASE SETUP
-- ============================================
-- For MySQL/MariaDB on Hostinger
-- Run this file to create all tables and initial data
-- ============================================

-- Create Database (if not exists)
CREATE DATABASE IF NOT EXISTS greengrassstore CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE greengrassstore;

-- ============================================
-- 1. PRODUCTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS products (
  id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
  name VARCHAR(500) NOT NULL,
  name_ar VARCHAR(500),
  slug VARCHAR(500) UNIQUE NOT NULL,
  description TEXT,
  description_ar TEXT,
  price DECIMAL(10,2) NOT NULL DEFAULT 0,
  compare_at_price DECIMAL(10,2),
  currency VARCHAR(10) NOT NULL DEFAULT 'AED',
  category VARCHAR(255),
  subcategory VARCHAR(255),
  featured_image TEXT,
  images JSON,
  is_featured BOOLEAN DEFAULT FALSE,
  is_on_sale BOOLEAN DEFAULT FALSE,
  is_new BOOLEAN DEFAULT FALSE,
  is_active BOOLEAN DEFAULT TRUE,
  stock_quantity INT DEFAULT 0,
  sku VARCHAR(100),
  tags JSON,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_slug (slug),
  INDEX idx_category (category),
  INDEX idx_is_active (is_active),
  INDEX idx_is_featured (is_featured)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 2. CATEGORIES TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS categories (
  id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
  name VARCHAR(255) NOT NULL,
  name_ar VARCHAR(255),
  slug VARCHAR(255) UNIQUE NOT NULL,
  description TEXT,
  description_ar TEXT,
  image TEXT,
  parent_id VARCHAR(36),
  display_order INT DEFAULT 0,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE SET NULL,
  INDEX idx_slug (slug),
  INDEX idx_parent (parent_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 3. BLOG POSTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS blog_posts (
  id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
  title VARCHAR(500) NOT NULL,
  title_ar VARCHAR(500),
  slug VARCHAR(500) UNIQUE NOT NULL,
  excerpt TEXT,
  excerpt_ar TEXT,
  content LONGTEXT,
  content_ar LONGTEXT,
  featured_image TEXT,
  category VARCHAR(255),
  author_name VARCHAR(255),
  reading_time INT DEFAULT 5,
  view_count INT DEFAULT 0,
  status VARCHAR(50) DEFAULT 'draft',
  published_at TIMESTAMP NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_slug (slug),
  INDEX idx_status (status),
  INDEX idx_category (category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 4. ORDERS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS orders (
  id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
  order_number VARCHAR(100) UNIQUE NOT NULL,
  user_id VARCHAR(36),
  customer_name VARCHAR(255) NOT NULL,
  customer_email VARCHAR(255) NOT NULL,
  customer_phone VARCHAR(50),
  customer_address TEXT,
  items JSON NOT NULL,
  subtotal DECIMAL(10,2) NOT NULL DEFAULT 0,
  tax DECIMAL(10,2) NOT NULL DEFAULT 0,
  shipping DECIMAL(10,2) NOT NULL DEFAULT 0,
  discount DECIMAL(10,2) DEFAULT 0,
  coupon_code VARCHAR(100),
  total DECIMAL(10,2) NOT NULL DEFAULT 0,
  status VARCHAR(50) NOT NULL DEFAULT 'pending',
  payment_method VARCHAR(100),
  payment_status VARCHAR(50) DEFAULT 'pending',
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_order_number (order_number),
  INDEX idx_customer_email (customer_email),
  INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 5. COUPONS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS coupons (
  id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
  code VARCHAR(100) UNIQUE NOT NULL,
  type VARCHAR(50) NOT NULL DEFAULT 'percentage',
  value DECIMAL(10,2) NOT NULL,
  min_purchase DECIMAL(10,2) DEFAULT 0,
  max_discount DECIMAL(10,2),
  usage_limit INT,
  used_count INT DEFAULT 0,
  start_date TIMESTAMP NULL,
  end_date TIMESTAMP NULL,
  is_active BOOLEAN DEFAULT TRUE,
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_code (code),
  INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 6. SITE SETTINGS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS site_settings (
  id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
  setting_key VARCHAR(255) UNIQUE NOT NULL,
  setting_value JSON NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_setting_key (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 7. SUBSCRIBERS TABLE (Newsletter)
-- ============================================
CREATE TABLE IF NOT EXISTS subscribers (
  id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
  email VARCHAR(255) UNIQUE NOT NULL,
  name VARCHAR(255),
  is_active BOOLEAN DEFAULT TRUE,
  subscribed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  unsubscribed_at TIMESTAMP NULL,
  INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 8. USERS TABLE (Admin/Customers)
-- ============================================
CREATE TABLE IF NOT EXISTS users (
  id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255),
  full_name VARCHAR(255),
  phone VARCHAR(50),
  role VARCHAR(50) DEFAULT 'customer',
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_email (email),
  INDEX idx_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 9. HERO SLIDER TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS hero_sliders (
  id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
  title VARCHAR(500),
  title_ar VARCHAR(500),
  description TEXT,
  description_ar TEXT,
  image TEXT NOT NULL,
  button_text VARCHAR(255),
  button_text_ar VARCHAR(255),
  button_link VARCHAR(500),
  display_order INT DEFAULT 0,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_display_order (display_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- 10. CUSTOM REQUESTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS custom_requests (
  id VARCHAR(36) PRIMARY KEY DEFAULT (UUID()),
  customer_name VARCHAR(255) NOT NULL,
  customer_email VARCHAR(255) NOT NULL,
  customer_phone VARCHAR(50),
  request_type VARCHAR(100),
  description TEXT NOT NULL,
  budget_range VARCHAR(100),
  images JSON,
  status VARCHAR(50) DEFAULT 'pending',
  admin_notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_status (status),
  INDEX idx_customer_email (customer_email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- INSERT DEFAULT SETTINGS
-- ============================================

-- Store Info
INSERT INTO site_settings (setting_key, setting_value) VALUES
('store_info', JSON_OBJECT(
  'name', 'Green Grass Store',
  'email', 'info@greengrassstore.com',
  'phone', '+971547751901',
  'address', 'Dubai, UAE',
  'currency', 'AED'
))
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

-- WhatsApp Settings
INSERT INTO site_settings (setting_key, setting_value) VALUES
('whatsapp', JSON_OBJECT(
  'phone', '+971547751901',
  'enabled', true,
  'welcomeMessage', 'Hello! Welcome to Green Grass Store. How can we help you today?'
))
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

-- Shipping Settings
INSERT INTO site_settings (setting_key, setting_value) VALUES
('shipping', JSON_OBJECT(
  'freeShippingThreshold', 200,
  'flatRate', 25,
  'enabled', true
))
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

-- Tax Settings
INSERT INTO site_settings (setting_key, setting_value) VALUES
('tax', JSON_OBJECT(
  'rate', 5,
  'enabled', true
))
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

-- ============================================
-- INSERT SAMPLE CATEGORIES
-- ============================================
INSERT INTO categories (id, name, name_ar, slug, description, is_active) VALUES
(UUID(), 'Indoor Plants', 'نباتات داخلية', 'indoor-plants', 'Beautiful plants for indoor spaces', TRUE),
(UUID(), 'Outdoor Plants', 'نباتات خارجية', 'outdoor-plants', 'Hardy plants for outdoor gardens', TRUE),
(UUID(), 'Pots & Planters', 'أصص ومزهريات', 'pots-planters', 'Decorative pots and planters', TRUE),
(UUID(), 'Garden Tools', 'أدوات الحديقة', 'garden-tools', 'Essential gardening tools', TRUE),
(UUID(), 'Gifts', 'هدايا', 'gifts', 'Perfect plant gifts', TRUE),
(UUID(), 'Seeds', 'بذور', 'seeds', 'Quality seeds for your garden', TRUE)
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- ============================================
-- INSERT DEFAULT ADMIN USER
-- ============================================
-- Password: admin123 (Please change after first login!)
INSERT INTO users (id, email, password_hash, full_name, role, is_active) VALUES
(UUID(), 'admin@greengrassstore.com', '$2a$10$rL5h0zKJ3yYxKxYH5rYxF.vKxH5kH5rYxF5rYxF5rYxF5rYxF5rY', 'Admin User', 'admin', TRUE)
ON DUPLICATE KEY UPDATE email = VALUES(email);

-- ============================================
-- CREATE VIEWS FOR EASY ACCESS
-- ============================================

-- Active Products View
CREATE OR REPLACE VIEW active_products AS
SELECT * FROM products WHERE is_active = TRUE;

-- Featured Products View
CREATE OR REPLACE VIEW featured_products AS
SELECT * FROM products WHERE is_featured = TRUE AND is_active = TRUE;

-- Published Blog Posts View
CREATE OR REPLACE VIEW published_posts AS
SELECT * FROM blog_posts WHERE status = 'published';

-- Pending Orders View
CREATE OR REPLACE VIEW pending_orders AS
SELECT * FROM orders WHERE status = 'pending';

-- ============================================
-- COMPLETED!
-- ============================================
-- Database setup complete!
-- Default admin login: admin@greengrassstore.com / admin123
-- IMPORTANT: Change admin password after first login!
-- ============================================
